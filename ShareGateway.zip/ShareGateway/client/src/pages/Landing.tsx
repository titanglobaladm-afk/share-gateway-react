import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Heart, Award, ArrowRight } from 'lucide-react';
import heroImage from '@assets/generated_images/SHARE_mobile_clinic_hero_87c47622.png';
import missionImage from '@assets/generated_images/Mission_section_healthcare_scene_462b77a4.png';

export default function Landing() {
  const [, setLocation] = useLocation();
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <img
          src={heroImage}
          alt="SHARE Mobile Clinic serving communities in Haiti"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6" data-testid="text-hero-title">
            Welcome to SHARE Gateway
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-white/90">
            Professional training and onboarding for SHARE Mobile Clinic team members in Haiti
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-primary text-primary-foreground border border-primary-border"
              onClick={() => setLocation('/register')}
              data-testid="button-hero-register"
            >
              Get Started
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-background/10 backdrop-blur-md border-white/20 text-white hover:bg-background/20"
              onClick={() => setLocation('/login')}
              data-testid="button-hero-login"
            >
              Sign In
            </Button>
          </div>
        </div>
      </section>

      {/* Mission Statement Section */}
      <section className="py-12 md:py-16 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-mission-title">
                Our Mission
              </h2>
              <p className="text-lg text-muted-foreground mb-4">
                SHARE Mobile Clinic brings accessible, high-quality healthcare to underserved communities in Haiti through mobile medical services, health education, and community partnerships.
              </p>
              <p className="text-lg text-muted-foreground">
                The SHARE Gateway platform ensures every team member—whether staff, investor, or partner—receives comprehensive training to support our mission effectively.
              </p>
            </div>
            <div className="rounded-lg overflow-hidden">
              <img
                src={missionImage}
                alt="SHARE healthcare workers serving the community"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Who It's For Section */}
      <section className="py-12 md:py-16 bg-card">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12" data-testid="text-who-title">
            Who It's For
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="hover-elevate" data-testid="card-staff">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Staff Members</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Healthcare providers, administrators, and support staff working directly with communities in Haiti.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate" data-testid="card-investors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Investors</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Financial supporters who want to understand our operations and impact on the ground.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate" data-testid="card-partners">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Award className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Partners</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Organizations and individuals collaborating with SHARE to expand healthcare access.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-12 md:py-16 bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12" data-testid="text-how-title">
            How It Works
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '1', title: 'Register', description: 'Create your account with email and password' },
              { step: '2', title: 'Get Assigned', description: 'Receive courses tailored to your role' },
              { step: '3', title: 'Complete Courses', description: 'Learn through lessons and interactive quizzes' },
              { step: '4', title: 'Get Certified', description: 'Track progress and earn completion certificates' },
            ].map((item, index) => (
              <div key={index} className="text-center" data-testid={`step-${item.step}`}>
                <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-16 bg-card">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-cta-title">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join the SHARE team and help bring healthcare to those who need it most.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button 
              size="lg"
              onClick={() => setLocation('/register')}
              data-testid="button-cta-register"
            >
              Register Now
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => setLocation('/login')}
              data-testid="button-cta-login"
            >
              Sign In
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
