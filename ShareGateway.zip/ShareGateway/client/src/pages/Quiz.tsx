import { useState } from 'react';
import { Link, useRoute, useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { ArrowLeft, CheckCircle2, XCircle, Award } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { UserCourse } from '@shared/schema';
import { getCourse } from '@/lib/courses';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';

export default function Quiz() {
  const [, params] = useRoute('/course/:courseId/quiz/:quizId');
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  const course = params?.courseId ? getCourse(params.courseId) : null;
  const quiz = course?.quizzes.find(q => q.id === params?.quizId);

  const { data: userCourse, isLoading } = useQuery<UserCourse>({
    queryKey: [`/api/user-courses/${params?.courseId}?userId=${user?.id}`],
    enabled: !!user && !!params?.courseId,
  });

  const completeQuizMutation = useMutation({
    mutationFn: async () => {
      if (!course || !quiz || !user) throw new Error('Missing data');
      
      return await apiRequest(
        'POST',
        `/api/courses/${course.id}/quizzes/${quiz.id}/complete`,
        {
          userId: user.id,
          totalLessons: course.lessons.length,
          totalQuizzes: course.quizzes.length,
        }
      );
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: [`/api/user-courses?userId=${user?.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/user-courses/${course?.id}?userId=${user?.id}`] });
      toast({
        title: 'Quiz passed!',
        description: `Great job! You scored ${score}%. Your progress has been saved.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save quiz completion',
        variant: 'destructive',
      });
    },
  });

  const handleSubmit = () => {
    if (!quiz || !userCourse || !course) return;

    const correctAnswers = quiz.questions.filter(
      (q, idx) => answers[idx] === q.correctAnswer
    ).length;
    const percentage = Math.round((correctAnswers / quiz.questions.length) * 100);
    setScore(percentage);
    setSubmitted(true);

    if (percentage >= 70) {
      const quizzesCompleted = userCourse.quizzesCompleted as string[];
      if (!quizzesCompleted.includes(quiz.id)) {
        completeQuizMutation.mutate();
      }
    } else {
      toast({
        title: 'Try again',
        description: `You scored ${percentage}%. You need 70% or higher to pass.`,
        variant: 'destructive',
      });
    }
  };

  const handleRetry = () => {
    setAnswers({});
    setSubmitted(false);
    setScore(0);
  };

  const handleBackToCourse = () => {
    setLocation(`/course/${course?.id}`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!course || !quiz || !userCourse) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardContent className="py-12 text-center">
            <h2 className="text-xl font-semibold mb-2">Quiz Not Found</h2>
            <p className="text-muted-foreground mb-6">
              This quiz doesn't exist or you don't have access to it.
            </p>
            <Button onClick={() => window.location.href = '/dashboard'}>Back to Dashboard</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isCompleted = (userCourse.quizzesCompleted as string[]).includes(quiz.id);
  const allQuestionsAnswered = quiz.questions.every((_, idx) => answers[idx] !== undefined);

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-3xl mx-auto px-4 md:px-8">
        <div className="mb-6">
          <Button variant="ghost" className="mb-4" onClick={() => setLocation(`/course/${course.id}`)} data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Course
          </Button>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">{course.title}</p>
                <CardTitle className="text-2xl md:text-3xl" data-testid="text-quiz-title">
                  {quiz.title}
                </CardTitle>
                <p className="text-muted-foreground mt-2">
                  {quiz.questions.length} questions • Pass with 70% or higher
                </p>
              </div>
              {isCompleted && (
                <Badge className="bg-chart-2 text-white" data-testid="badge-completed">
                  <CheckCircle2 className="w-4 h-4 mr-1" />
                  Completed
                </Badge>
              )}
            </div>
          </CardHeader>
        </Card>

        {submitted && (
          <Card className={`mb-6 ${score >= 70 ? 'border-chart-2' : 'border-destructive'}`}>
            <CardContent className="py-8 text-center">
              {score >= 70 ? (
                <>
                  <Award className="w-16 h-16 mx-auto mb-4 text-chart-2" />
                  <h2 className="text-2xl font-bold mb-2 text-chart-2">Congratulations!</h2>
                  <p className="text-lg mb-4">You passed with {score}%</p>
                </>
              ) : (
                <>
                  <XCircle className="w-16 h-16 mx-auto mb-4 text-destructive" />
                  <h2 className="text-2xl font-bold mb-2">Not quite there yet</h2>
                  <p className="text-lg mb-4">You scored {score}%. Try again to pass!</p>
                </>
              )}
              <div className="flex gap-4 justify-center">
                {score >= 70 ? (
                  <Button onClick={handleBackToCourse} data-testid="button-back-to-course">
                    Back to Course
                  </Button>
                ) : (
                  <Button onClick={handleRetry} data-testid="button-retry">
                    Try Again
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-6">
          {quiz.questions.map((question, qIdx) => {
            const userAnswer = answers[qIdx];
            const isCorrect = userAnswer === question.correctAnswer;
            const showResult = submitted;

            return (
              <Card
                key={qIdx}
                className={showResult ? (isCorrect ? 'border-chart-2' : 'border-destructive') : ''}
                data-testid={`question-${qIdx}`}
              >
                <CardHeader>
                  <CardTitle className="text-lg flex items-start gap-3">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                      {qIdx + 1}
                    </span>
                    <span className="flex-1">{question.question}</span>
                    {showResult && (
                      isCorrect ? (
                        <CheckCircle2 className="w-6 h-6 text-chart-2 flex-shrink-0" />
                      ) : (
                        <XCircle className="w-6 h-6 text-destructive flex-shrink-0" />
                      )
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={userAnswer?.toString()}
                    onValueChange={(value) => {
                      if (!submitted) {
                        setAnswers({ ...answers, [qIdx]: parseInt(value) });
                      }
                    }}
                    disabled={submitted}
                  >
                    {question.choices.map((choice, cIdx) => {
                      const isThisCorrect = cIdx === question.correctAnswer;
                      const isSelected = userAnswer === cIdx;
                      
                      return (
                        <div
                          key={cIdx}
                          className={`flex items-center space-x-3 p-4 rounded-md border transition-colors ${
                            submitted
                              ? isThisCorrect
                                ? 'bg-chart-2/10 border-chart-2'
                                : isSelected
                                ? 'bg-destructive/10 border-destructive'
                                : ''
                              : isSelected
                              ? 'bg-primary/5 border-primary'
                              : 'hover-elevate'
                          }`}
                          data-testid={`choice-${qIdx}-${cIdx}`}
                        >
                          <RadioGroupItem value={cIdx.toString()} id={`q${qIdx}-c${cIdx}`} />
                          <Label
                            htmlFor={`q${qIdx}-c${cIdx}`}
                            className="flex-1 cursor-pointer"
                          >
                            {choice}
                          </Label>
                        </div>
                      );
                    })}
                  </RadioGroup>
                  {showResult && !isCorrect && (
                    <p className="mt-4 text-sm text-muted-foreground">
                      Correct answer: {question.choices[question.correctAnswer]}
                    </p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {!submitted && (
          <div className="sticky bottom-6 bg-card border rounded-lg p-4 flex items-center justify-between gap-4 mt-6">
            <p className="text-sm text-muted-foreground">
              {allQuestionsAnswered
                ? 'All questions answered. Ready to submit?'
                : `${Object.keys(answers).length} of ${quiz.questions.length} answered`}
            </p>
            <Button
              onClick={handleSubmit}
              disabled={!allQuestionsAnswered || completeQuizMutation.isPending}
              data-testid="button-submit"
            >
              {completeQuizMutation.isPending ? 'Submitting...' : 'Submit Quiz'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
