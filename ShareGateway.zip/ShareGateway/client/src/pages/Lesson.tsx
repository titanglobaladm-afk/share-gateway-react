import { Link, useRoute, useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { UserCourse } from '@shared/schema';
import { getCourse } from '@/lib/courses';
import { useToast } from '@/hooks/use-toast';
import ReactMarkdown from 'react-markdown';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';

export default function Lesson() {
  const [, params] = useRoute('/course/:courseId/lesson/:lessonId');
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const course = params?.courseId ? getCourse(params.courseId) : null;
  const lesson = course?.lessons.find(l => l.id === params?.lessonId);

  const { data: userCourse, isLoading } = useQuery<UserCourse>({
    queryKey: [`/api/user-courses/${params?.courseId}?userId=${user?.id}`],
    enabled: !!user && !!params?.courseId,
  });

  const completeLessonMutation = useMutation({
    mutationFn: async () => {
      if (!course || !lesson || !user) throw new Error('Missing data');
      
      return await apiRequest(
        'POST',
        `/api/courses/${course.id}/lessons/${lesson.id}/complete`,
        {
          userId: user.id,
          totalLessons: course.lessons.length,
          totalQuizzes: course.quizzes.length,
        }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user-courses?userId=${user?.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/user-courses/${course?.id}?userId=${user?.id}`] });
      toast({
        title: 'Lesson completed!',
        description: 'Great job! Your progress has been saved.',
      });
      setLocation(`/course/${course?.id}`);
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to mark lesson as complete',
        variant: 'destructive',
      });
    },
  });

  const handleMarkComplete = () => {
    const lessonsCompleted = userCourse?.lessonsCompleted as string[] || [];
    if (lessonsCompleted.includes(lesson?.id || '')) {
      toast({
        title: 'Already completed',
        description: 'You have already completed this lesson.',
      });
      return;
    }
    completeLessonMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!course || !lesson || !userCourse) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardContent className="py-12 text-center">
            <h2 className="text-xl font-semibold mb-2">Lesson Not Found</h2>
            <p className="text-muted-foreground mb-6">
              This lesson doesn't exist or you don't have access to it.
            </p>
            <Button onClick={() => window.location.href = '/dashboard'}>Back to Dashboard</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isCompleted = (userCourse.lessonsCompleted as string[]).includes(lesson.id);

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-3xl mx-auto px-4 md:px-8">
        <div className="mb-6">
          <Button variant="ghost" className="mb-4" onClick={() => setLocation(`/course/${course.id}`)} data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Course
          </Button>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6 md:p-8">
            <div className="flex items-start justify-between mb-6">
              <div>
                <p className="text-sm text-muted-foreground mb-2">{course.title}</p>
                <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-lesson-title">
                  {lesson.title}
                </h1>
              </div>
              {isCompleted && (
                <Badge className="bg-chart-2 text-white" data-testid="badge-completed">
                  <CheckCircle2 className="w-4 h-4 mr-1" />
                  Completed
                </Badge>
              )}
            </div>

            <div className="prose prose-sm md:prose-base max-w-none font-serif">
              <ReactMarkdown>{lesson.content}</ReactMarkdown>
            </div>
          </CardContent>
        </Card>

        <div className="sticky bottom-6 bg-card border rounded-lg p-4 flex items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            {isCompleted ? 'You have completed this lesson' : 'Mark this lesson as complete to continue'}
          </p>
          <Button
            onClick={handleMarkComplete}
            disabled={completeLessonMutation.isPending || isCompleted}
            data-testid="button-mark-complete"
          >
            {completeLessonMutation.isPending ? 'Saving...' : isCompleted ? 'Completed' : 'Mark Complete'}
          </Button>
        </div>
      </div>
    </div>
  );
}
