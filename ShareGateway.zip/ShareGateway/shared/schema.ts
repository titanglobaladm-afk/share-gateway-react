import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Supabase user_courses table schema
export const userCourses = pgTable("user_courses", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  courseId: text("course_id").notNull(),
  assignedAt: timestamp("assigned_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  progressPercentage: integer("progress_percentage").notNull().default(0),
  lessonsCompleted: jsonb("lessons_completed").$type<string[]>().notNull().default([]),
  quizzesCompleted: jsonb("quizzes_completed").$type<string[]>().notNull().default([]),
});

export const insertUserCourseSchema = createInsertSchema(userCourses).omit({
  id: true,
  assignedAt: true,
});

export type InsertUserCourse = z.infer<typeof insertUserCourseSchema>;
export type UserCourse = typeof userCourses.$inferSelect;

// Frontend-only types for course structure
export interface Lesson {
  id: string;
  title: string;
  content: string;
}

export interface QuizQuestion {
  question: string;
  choices: string[];
  correctAnswer: number;
}

export interface Quiz {
  id: string;
  title: string;
  questions: QuizQuestion[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
  quizzes: Quiz[];
}
