import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { createClient } from '@supabase/supabase-js';

// Server uses non-VITE prefixed env vars
const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.warn('Warning: Supabase environment variables not configured');
}

const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Helper to convert snake_case DB fields to camelCase for TypeScript
  function toCamelCase(obj: any): any {
    return {
      id: obj.id,
      userId: obj.user_id,
      courseId: obj.course_id,
      assignedAt: obj.assigned_at,
      completedAt: obj.completed_at,
      progressPercentage: obj.progress_percentage,
      lessonsCompleted: obj.lessons_completed || [],
      quizzesCompleted: obj.quizzes_completed || [],
    };
  }

  // Helper function to calculate progress
  function calculateProgress(totalLessons: number, totalQuizzes: number, lessonsCompleted: string[], quizzesCompleted: string[]): number {
    const totalItems = totalLessons + totalQuizzes;
    const completedItems = lessonsCompleted.length + quizzesCompleted.length;
    return Math.round((completedItems / totalItems) * 100);
  }

  // Mark lesson as complete
  app.post('/api/courses/:courseId/lessons/:lessonId/complete', async (req, res) => {
    try {
      const { courseId, lessonId } = req.params;
      const userId = req.body.userId;
      const totalLessons = req.body.totalLessons;
      const totalQuizzes = req.body.totalQuizzes;

      if (!supabase) {
        return res.status(500).json({ error: 'Supabase not configured' });
      }

      // Get current user course
      const { data: userCourse, error: fetchError } = await supabase
        .from('user_courses')
        .select('*')
        .eq('user_id', userId)
        .eq('course_id', courseId)
        .single();

      if (fetchError) {
        return res.status(404).json({ error: 'User course not found' });
      }

      const lessonsCompleted = userCourse.lessons_completed as string[];
      
      // Don't add if already completed
      if (lessonsCompleted.includes(lessonId)) {
        return res.json({ message: 'Already completed', userCourse });
      }

      const newLessonsCompleted = [...lessonsCompleted, lessonId];
      const quizzesCompleted = userCourse.quizzes_completed as string[];
      const progressPercentage = calculateProgress(totalLessons, totalQuizzes, newLessonsCompleted, quizzesCompleted);

      const updateData: any = {
        lessons_completed: newLessonsCompleted,
        progress_percentage: progressPercentage,
      };

      if (progressPercentage === 100) {
        updateData.completed_at = new Date().toISOString();
      }

      const { data: updated, error: updateError } = await supabase
        .from('user_courses')
        .update(updateData)
        .eq('id', userCourse.id)
        .select()
        .single();

      if (updateError) {
        return res.status(500).json({ error: updateError.message });
      }

      res.json({ message: 'Lesson completed', userCourse: toCamelCase(updated) });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mark quiz as complete
  app.post('/api/courses/:courseId/quizzes/:quizId/complete', async (req, res) => {
    try {
      const { courseId, quizId } = req.params;
      const userId = req.body.userId;
      const totalLessons = req.body.totalLessons;
      const totalQuizzes = req.body.totalQuizzes;

      if (!supabase) {
        return res.status(500).json({ error: 'Supabase not configured' });
      }

      // Get current user course
      const { data: userCourse, error: fetchError } = await supabase
        .from('user_courses')
        .select('*')
        .eq('user_id', userId)
        .eq('course_id', courseId)
        .single();

      if (fetchError) {
        return res.status(404).json({ error: 'User course not found' });
      }

      const quizzesCompleted = userCourse.quizzes_completed as string[];
      
      // Don't add if already completed
      if (quizzesCompleted.includes(quizId)) {
        return res.json({ message: 'Already completed', userCourse });
      }

      const lessonsCompleted = userCourse.lessons_completed as string[];
      const newQuizzesCompleted = [...quizzesCompleted, quizId];
      const progressPercentage = calculateProgress(totalLessons, totalQuizzes, lessonsCompleted, newQuizzesCompleted);

      const updateData: any = {
        quizzes_completed: newQuizzesCompleted,
        progress_percentage: progressPercentage,
      };

      if (progressPercentage === 100) {
        updateData.completed_at = new Date().toISOString();
      }

      const { data: updated, error: updateError } = await supabase
        .from('user_courses')
        .update(updateData)
        .eq('id', userCourse.id)
        .select()
        .single();

      if (updateError) {
        return res.status(500).json({ error: updateError.message });
      }

      res.json({ message: 'Quiz completed', userCourse: toCamelCase(updated) });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get user courses
  app.get('/api/user-courses', async (req, res) => {
    try {
      const userId = req.query.userId as string;

      if (!supabase) {
        return res.status(500).json({ error: 'Supabase not configured' });
      }

      const { data, error } = await supabase
        .from('user_courses')
        .select('*')
        .eq('user_id', userId);

      if (error) {
        return res.status(500).json({ error: error.message });
      }

      res.json((data || []).map(toCamelCase));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get single user course
  app.get('/api/user-courses/:courseId', async (req, res) => {
    try {
      const { courseId } = req.params;
      const userId = req.query.userId as string;

      if (!supabase) {
        return res.status(500).json({ error: 'Supabase not configured' });
      }

      const { data, error } = await supabase
        .from('user_courses')
        .select('*')
        .eq('user_id', userId)
        .eq('course_id', courseId)
        .single();

      if (error) {
        return res.status(404).json({ error: 'Course not found' });
      }

      res.json(toCamelCase(data));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
